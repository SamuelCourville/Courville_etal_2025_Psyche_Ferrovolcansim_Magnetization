# Run Notes
## Run Parameters 
These are the values for the final set of runs. 
In both runs, the initial core sulfur content is for self-consistent mantle, core and bulk densities for Psyche.
All other parameters match Sanderson et. al. 2025 or are already stated in Table 1 in the paper draft.

### Run 1 - thin mantle
+ $\rho_m$=2750 kg m $^{-3}$
+ $\frac{r_c}{r}$ = 0.95
+ Initial core sulfur content $X_{S,0}$ = 27.2 wt %


### Run 2 - thick mantle
+ $\rho_m$=3750 kg m $^{-3}$
+ $\frac{r_c}{r}$ = 0.75
+ Initial core sulfur content $X_{S,0}$ = 23.7 wt %

## Model outputs
All output values are in the npz files as before. The average B and $Re_m$ are in run_1_averaged.npz and run_2_averaged.npz.
Both runs have a rolling average over 5 Myr after solidification and a 1Myr rolling average before solidification. 
The rolling average before core solidification is, because the slight spikes in the heat flux were making Rem oscillate around supercritical.
These two plots show the raw and averaged traces
![run1](run_1_B.png) ![run2](run_2_B.png) 

### Thermal vs compositional dynamos
In run 1, core solidification begins at 8.1Ma after CAI formation and in run 2 core solidification begins 6Ma after CAI formation.
In both runs, there is a short epoch of thermal dynamo generation before the onset of core solification. Once the core begins to solidify it is the dominant contribution to the dynamo.